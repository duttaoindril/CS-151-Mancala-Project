Contacts:
=========
Oindril: duttaoindril@gmail.com; 408-658-8961

Eoin: eoinwilliammurphy@gmail.com; 714-657-8523

Nan: nanthana.thanonklin@sjsu.edu; 415-676-1766

Tom: thomas.ryan@sjsu.edu; 901-219-3870

Game Rules:
===========
1. board has 12 pits (6 per player), 2 mancala, and N stones 
2. if player has stones left on their side then player can select one pit to play
3. If the last piece you drop is in an empty hole on your side, you capture that piece and any pieces in the hole directly opposite ( similar to no.3 but clearer?) yeah
4. if a pit with n stones is selected then deposit one stone in each successive pit until n stones deposited (counter­clockwise)
5. if last stone played lands in player’s mancala then player gains another turn
6. if played stones pass player's own mancala then deposits one stone in the player’s mancala
7. if played stones pass opponent's mancala then skip opponent's mancala
8. if player selects undo then board resets to beginning of turn; note: only three undos allowed per turn; note: player is not allowed to make multiple undos in a row
9. The game is over when all 6 pits on one side is empty, however, the players with remaining  stones left in his/her pits get to collect all the remaining stones on his/her side.
10. if player has more stones in mancala then player wins

Relevant Project Links:
=======================
https://drive.google.com/open?id=0Bzf4Aj6N26XUMXVSZk14MnlBQ00
